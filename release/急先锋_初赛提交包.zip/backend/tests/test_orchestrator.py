import asyncio
import json
import time
from pathlib import Path

import httpx

from app import llm_planner as llm_planner_module
from app import orchestrator as orchestrator_module
from app.database import Database
from app.knowledge_base import KnowledgeRepository
from app.memory import MemoryRepository
from app.registry import AgentRegistryService
from app.scheduler import AGENTS
from app.tools import ToolRepository
from app.workflow_engine import WorkflowRepository


class FakeAgentArts:
    enabled = True

    def __init__(self):
        self.started_at = {}

    @property
    def status(self):
        return {"enabled": True, "agent_coverage": "4/4"}

    def override_endpoint(self, agent_id, endpoint):
        return None

    def endpoint_for(self, agent_id):
        return f"https://example.com/{agent_id}/invocations"

    async def invoke(self, agent_id, payload, session_id="farmmatch", client=None):
        self.started_at[agent_id] = time.monotonic()
        await asyncio.sleep(0.15)
        if payload.get("task_type") == "rework_strategy":
            text = json.dumps({
                "selected_policy": payload["allowed_policies"][0]["id"],
                "rationale": "测试环境：从允许策略中选择路线故障转移。",
            })
        elif agent_id == "matching_agent":
            text = json.dumps({"recommended_plan_id": payload["plans"][0]["plan_id"]})
        elif agent_id == "delivery_agent":
            text = json.dumps({"recommended_plan_id": "PLAN-STALE", "summary": "stale delivery summary", "risk_alerts": ["stale delivery risk"]})
        elif agent_id == "verifier_agent":
            text = json.dumps({"verdict": "pass", "score": 100})
        elif agent_id == "risk_extension":
            text = json.dumps({"risks": ["扩展风险：需核对夜间运输"]})
        else:
            text = json.dumps({"summary": "ok"})
        return {"mode": "agentarts", "agent_id": agent_id, "text": text, "stream_events": 1}


class BlockingDemandAgentArts(FakeAgentArts):
    def __init__(self):
        super().__init__()
        self.demand_started = False
        self.demand_cancelled = False

    async def invoke(self, agent_id, payload, session_id="farmmatch", client=None):
        if agent_id == "demand_agent":
            self.demand_started = True
            try:
                await asyncio.sleep(10)
            except asyncio.CancelledError:
                self.demand_cancelled = True
                raise
        return await super().invoke(agent_id, payload, session_id=session_id, client=client)


class FakeLLM:
    @property
    def status(self):
        return {"enabled": False}

    async def reflect(self, agent_id, payload, evidence):
        return {"agent_id": agent_id, "source": "test"}


def test_background_demand_task_is_cancelled_when_pipeline_fails(tmp_path: Path, monkeypatch):
    db = Database(tmp_path / "background-cancel.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("rainstorm-ii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": scenario["closed_routes"],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"],
                "quantity": item["quantity"], "priority": item["priority"],
                "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    run_id = "RUN-BACKGROUND-CANCEL"
    db.create_run(run_id, scenario["id"], request)
    fake = BlockingDemandAgentArts()
    monkeypatch.setattr(orchestrator_module, "AgentArtsBridge", lambda: fake)
    monkeypatch.setattr(orchestrator_module, "LLMService", FakeLLM)

    def fail_generation(*args, **kwargs):
        raise RuntimeError("forced pipeline failure")

    monkeypatch.setattr(orchestrator_module, "generate_plans", fail_generation)
    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))

    run = db.get_run(run_id)
    assert run["status"] == "failed"
    assert fake.demand_started is True
    assert fake.demand_cancelled is True

class FakeLLMPlanner:
    enabled = True
    last_available_tools = []

    @property
    def status(self):
        return {"enabled": True, "role": "planning-and-replanning", "model": "test-planner"}

    async def create_plan(self, user_request, available_tools):
        type(self).last_available_tools = list(available_tools)
        return {
            "mode": "llm-planner", "summary": "测试计划",
            "steps": [
                {"id": "S1", "tool": "demand_plan", "reason": "normalize", "input": {}, "expected_output": "demand"},
                {"id": "S2", "tool": "verify_plans", "reason": "invalid order", "input": {}, "expected_output": "verification"},
                {"id": "S3", "tool": "generate_plans", "reason": "generate", "input": {}, "expected_output": "plans"},
                {"id": "S4", "tool": "verify_plans", "reason": "verify", "input": {}, "expected_output": "verification"},
                {"id": "S5", "tool": "delivery_package", "reason": "deliver", "input": {}, "expected_output": "delivery"},
            ],
        }

    async def decide(self, step_result, remaining_steps, current_context):
        if step_result.get("tool") == "delivery_package":
            return {"mode": "llm-planner", "decision": "stop", "next_tool": None, "reason": "交付完成", "repair_policy": ""}
        next_tool = remaining_steps[0]["tool"] if remaining_steps else None
        return {"mode": "llm-planner", "decision": "continue", "next_tool": next_tool, "reason": "继续计划", "repair_policy": ""}


class FakeLLMPlannerWithUnknownTool(FakeLLMPlanner):
    last_unknown_error = ""

    async def create_plan(self, user_request, available_tools):
        plan = await super().create_plan(user_request, available_tools)
        plan["steps"].insert(0, {
            "id": "S0", "tool": "ghost_tool", "reason": "测试未注册工具",
            "input": {}, "expected_output": "error",
        })
        return plan

    async def decide(self, step_result, remaining_steps, current_context):
        if step_result.get("tool") == "ghost_tool":
            type(self).last_unknown_error = str((step_result.get("result") or {}).get("error") or "")
        return await super().decide(step_result, remaining_steps, current_context)


def test_planner_jumps_verify_to_later_generate_and_completes(tmp_path: Path, monkeypatch):
    db = Database(tmp_path / "planner-orchestrator.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("heatwave-iii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": [],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"],
                "quantity": item["quantity"], "priority": item["priority"],
                "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    water_id = by_code["MAT-WATER-001"]["id"]
    with db.connect() as conn:
        conn.execute("UPDATE inventory SET quantity=3000, locked_quantity=0 WHERE material_id=?", (water_id,))
    run_id = "RUN-LLM-PLANNER"
    db.create_run(run_id, scenario["id"], request)
    monkeypatch.setattr(orchestrator_module, "LLMPlanner", lambda: FakeLLMPlanner())
    monkeypatch.setattr(orchestrator_module, "LLMService", FakeLLM)
    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))
    run = db.get_run(run_id)
    assert run["status"] == "awaiting_approval", run.get("result")
    assert run["result"]["runtime"] == "llm-planner"
    assert run["result"]["planner_trace"]["executed_steps"] == 4
    assert len(run["result"]["rounds"]) == 1
    assert run["result"]["planner_trace"]["decisions"][-1]["decision"]["decision"] == "stop"
    decisions_by_id = {item["id"]: item for item in run["result"]["ai_decision_matrix"]}
    assert decisions_by_id["D8"]["applied"] is True
    assert decisions_by_id["D8"]["source"] == "llm-planner"
    assert decisions_by_id["D3"]["applied"] is False
    assert decisions_by_id["D3"]["source"] == "deterministic-scorer"
    events = db.events_after(run_id)
    event_types = [event["type"] for event in events]
    assert "llm.thinking" in event_types
    assert "a2a.message" in event_types
    a2a_history = db.list_a2a_messages(run_id)
    assert len(a2a_history) == 2
    assert {item["message_type"] for item in a2a_history} == {"request", "reply"}
    started_agents = {
        event["agent_id"] for event in events
        if event["type"] == "agent.started" and event["agent_id"] in {"demand_agent", "matching_agent", "verifier_agent", "delivery_agent"}
    }
    assert started_agents == {"demand_agent", "matching_agent", "verifier_agent", "delivery_agent"}
    completed_planner_events = [
        event for event in events
        if event["type"] == "agent.completed" and event["payload"].get("runtime") == "llm-planner"
    ]
    assert len(completed_planner_events) == run["result"]["planner_trace"]["executed_steps"]
    with db.connect() as conn:
        tool_call_count = conn.execute(
            "SELECT COUNT(*) AS count FROM tool_calls WHERE tool_id LIKE 'planner:%' AND session_id=?",
            (run_id,),
        ).fetchone()["count"]
        planner_performance_count = conn.execute(
            "SELECT COUNT(*) AS count FROM agent_performance WHERE agent_id='planner' AND run_id=?",
            (run_id,),
        ).fetchone()["count"]
    assert tool_call_count == run["result"]["planner_trace"]["executed_steps"]
    assert planner_performance_count >= run["result"]["planner_trace"]["executed_steps"] + 1

def test_planner_mode_runs_post_verification_extensions_and_registered_tools(tmp_path: Path, monkeypatch):
    db = Database(tmp_path / "planner-extension.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("heatwave-iii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": scenario["closed_routes"],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"],
                "quantity": item["quantity"],
                "priority": item["priority"],
                "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    water_id = by_code["MAT-WATER-001"]["id"]
    with db.connect() as conn:
        conn.execute("UPDATE inventory SET quantity=3000, locked_quantity=0 WHERE material_id=?", (water_id,))
    registry = AgentRegistryService(db)
    registry.sync_builtin_agents(AGENTS)
    registry.register_agent({
        "id": "risk_extension",
        "name": "核验后风险扩展 Agent",
        "role": "risk-review",
        "description": "核验后追加风险审查",
        "capabilities": ["风险复核"],
        "version": "v1",
        "endpoint": "https://example.com/risk-extension/invocations",
        "model": "test",
        "prompt_version": "v1",
    })
    WorkflowRepository(db).save_workflow("planner-post-review", {
        "name": "Planner 核验后扩展审查",
        "stage": "post_verification",
        "definition": {
            "nodes": [{
                "id": "A05",
                "type": "agent",
                "agent_id": "risk_extension",
                "depends_on": [],
                "on_error": "continue",
            }]
        },
    })
    tools = ToolRepository(db)
    tools.ensure_builtins()
    tools.save_tool("knowledge_search", {
        "name": "知识库混合检索", "kind": "builtin", "enabled": False,
        "input_schema": {"type": "object", "properties": {}},
    })
    run_id = "RUN-LLM-PLANNER-EXTENSION"
    db.create_run(run_id, scenario["id"], request)
    fake = FakeAgentArts()
    monkeypatch.setattr(orchestrator_module, "AgentArtsBridge", lambda: fake)
    monkeypatch.setattr(orchestrator_module, "LLMService", FakeLLM)
    monkeypatch.setattr(orchestrator_module, "LLMPlanner", lambda: FakeLLMPlannerWithUnknownTool())
    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))
    run = db.get_run(run_id)
    assert run["status"] == "awaiting_approval", run.get("result")
    assert "demand_plan" in FakeLLMPlannerWithUnknownTool.last_available_tools
    assert "generate_plans" in FakeLLMPlannerWithUnknownTool.last_available_tools
    assert "verify_plans" in FakeLLMPlannerWithUnknownTool.last_available_tools
    assert "delivery_package" in FakeLLMPlannerWithUnknownTool.last_available_tools
    assert "knowledge_search" not in FakeLLMPlannerWithUnknownTool.last_available_tools
    assert "rag_retrieve" not in FakeLLMPlannerWithUnknownTool.last_available_tools
    assert "不存在或未启用" in FakeLLMPlannerWithUnknownTool.last_unknown_error
    assert {item["agent_id"] for item in run["result"]["extension_reviews"]} == {"risk_extension"}
    assert {item["stage"] for item in run["result"]["extension_workflow_runs"]} == {"post_verification"}
    assert "risk_extension" in run["result"]["agentarts_trace"]
    assert run["result"]["delivery"]["extension_reviews"][0]["agent_id"] == "risk_extension"


def test_planner_invalid_json_retries_then_main_run_still_delivers(tmp_path: Path, monkeypatch):
    class InvalidJsonClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def post(self, url, headers=None, json=None):
            return httpx.Response(
                200,
                request=httpx.Request("POST", url),
                json={"choices": [{"message": {"content": "not-json"}}]},
            )

    db = Database(tmp_path / "planner-invalid-json.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("heatwave-iii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": [],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"],
                "quantity": item["quantity"], "priority": item["priority"],
                "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    water_id = by_code["MAT-WATER-001"]["id"]
    with db.connect() as conn:
        conn.execute("UPDATE inventory SET quantity=3000, locked_quantity=0 WHERE material_id=?", (water_id,))
    run_id = "RUN-PLANNER-BAD-JSON"
    db.create_run(run_id, scenario["id"], request)
    monkeypatch.setattr(llm_planner_module.httpx, "AsyncClient", lambda **kwargs: InvalidJsonClient())
    monkeypatch.setattr(
        orchestrator_module, "LLMPlanner",
        lambda: llm_planner_module.LLMPlanner(
            db, run_id, enabled=True, base_url="https://example.com/v1",
            api_key="real-key", model="test-model",
        ),
    )
    monkeypatch.setattr(orchestrator_module, "LLMService", FakeLLM)
    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))
    run = db.get_run(run_id)
    assert run["status"] == "awaiting_approval", run.get("result")
    assert run["result"]["runtime"] == "llm-planner"
    assert run["result"]["delivery"]["status"] == "ready"
    with db.connect() as conn:
        rows = conn.execute("SELECT status, fallback FROM llm_calls WHERE run_id=? ORDER BY id", (run_id,)).fetchall()
    assert len(rows) >= 2
    assert [row["status"] for row in rows[:2]] == ["invalid_json", "invalid_json"]
    assert rows[1]["fallback"] == 1


def test_matching_and_verifier_cloud_reviews_run_in_parallel(tmp_path: Path, monkeypatch):
    db = Database(tmp_path / "parallel-orchestrator.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("rainstorm-ii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    demand_items = [
        {
            "material_id": by_code[item["material_code"]]["id"],
            "quantity": item["quantity"],
            "priority": item["priority"],
            "deadline_hours": item["deadline_hours"],
        }
        for item in scenario["default_demand"]
    ]
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"],
            "severity": scenario["severity"],
            "location": scenario["location"],
            "affected_population": scenario["affected_population"],
            "closed_route_ids": scenario["closed_routes"],
        },
        "demand_items": demand_items,
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    run_id = "RUN-PARALLEL-TEST"
    AgentRegistryService(db).register_agent({
        "id": "risk_extension",
        "name": "扩展风险审查",
        "role": "risk-review",
        "description": "动态注册的扩展审查节点",
        "capabilities": ["night-transport-risk"],
        "version": "v1",
        "endpoint": "https://example.com/risk-extension/invocations",
        "model": "test",
        "prompt_version": "v1",
    })
    AgentRegistryService(db).register_agent({
        "id": "demand_extension",
        "name": "需求后扩展审查",
        "role": "demand-review",
        "description": "需求阶段动态节点",
        "capabilities": ["demand-risk"],
        "version": "v1",
        "endpoint": "https://example.com/demand-extension/invocations",
        "model": "test",
        "prompt_version": "v1",
    })
    WorkflowRepository(db).save_workflow("after-demand-review", {
        "name": "需求后扩展审查",
        "stage": "after_demand",
        "definition": {
            "nodes": [
                {"id": "A01X", "type": "agent", "agent_id": "demand_extension", "depends_on": [], "on_error": "continue"}
            ]
        },
    })
    WorkflowRepository(db).save_workflow("post-review", {
        "name": "核验后扩展审查",
        "stage": "post_verification",
        "definition": {
            "nodes": [
                {
                    "id": "A05",
                    "type": "agent",
                    "agent_id": "risk_extension",
                    "depends_on": [],
                    "on_error": "continue",
                }
            ]
        },
    })
    db.create_run(run_id, scenario["id"], request)
    fake = FakeAgentArts()
    monkeypatch.setattr(orchestrator_module, "AgentArtsBridge", lambda: fake)
    monkeypatch.setattr(orchestrator_module, "LLMService", FakeLLM)

    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))

    run = db.get_run(run_id)
    assert run["status"] == "awaiting_approval", run.get("result")
    assert set(run["result"]["agentarts_trace"]) == {
        "demand_agent", "matching_agent", "verifier_agent", "delivery_agent",
        "risk_extension", "demand_extension", "rework_policy",
    }
    assert abs(fake.started_at["matching_agent"] - fake.started_at["verifier_agent"]) < 0.2
    scheduler_metrics = run["result"]["orchestration"]["runtime_metrics"]
    assert scheduler_metrics["engine"] == "asyncio.PriorityQueue"
    assert scheduler_metrics["total_tasks"] >= 6
    assert scheduler_metrics["peak_concurrency"] >= 2
    decisions = {item["id"]: item for item in run["result"]["ai_decision_matrix"]}
    assert decisions["D1"]["applied"] is False
    assert decisions["D1"]["narrative_applied"] is True
    assert decisions["D1"]["priority_advisory_applied"] is False
    assert decisions["D2"]["applied"] is False
    assert decisions["D2"]["source"] == "deterministic-single-policy"
    assert decisions["D3"]["applied"] is True
    assert decisions["D6"]["applied"] is False
    assert decisions["D6"]["source"] == "agentarts-audit-only"
    assert decisions["D6"]["discarded_fields"]
    assert run["result"]["prompt_adaptations"]
    assert run["result"]["prompt_adaptations"][0]["active_version"].startswith("v1.4+adaptive")
    assert run["result"]["loop_metrics"]["adaptive_prompt_versions"]
    assert run["result"]["loop_metrics"]["adaptive_tool_overrides"]
    assert all(run["result"]["loop_metrics"]["workflow_paths"])
    assert all("citation" in item for item in run["result"]["retrieval"])
    assert run["result"]["active_prompt_versions"]["matching_agent"].startswith("v1.4+adaptive")
    assert {item["agent_id"] for item in run["result"]["extension_reviews"]} == {"risk_extension", "demand_extension"}
    assert {item["stage"] for item in run["result"]["extension_workflow_runs"]} == {"after_demand", "post_verification"}
    assert all(item["status"] == "success" for item in run["result"]["extension_workflow_runs"])
    assert any("扩展风险" in item for item in run["result"]["delivery"]["risk_alerts"])
    interpretation = run["result"]["delivery"]["agentarts_interpretation"]
    assert interpretation["review_status"] == "audit-only"
    assert interpretation["recommendation_consistency"] == "stale-plan"
    assert "stale delivery risk" not in run["result"]["delivery"]["risk_alerts"]


def test_core_workflow_can_replace_verifier_with_two_agent_vote(tmp_path: Path):
    db = Database(tmp_path / "core-vote.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("rainstorm-ii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": scenario["closed_routes"],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"],
                "quantity": item["quantity"], "priority": item["priority"],
                "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    registry = AgentRegistryService(db)
    for agent_id in ("verifier_a", "verifier_b"):
        registry.register_agent({
            "id": agent_id,
            "name": f"独立核验 {agent_id[-1].upper()}",
            "role": "verifier-review",
            "description": "本地与云端均可执行的双核验节点",
            "capabilities": ["inventory-verify", "route-verify", "vote"],
            "version": "v1",
            "endpoint": "",
            "model": "local-rule-agent",
            "prompt_version": "v1",
        })
    WorkflowRepository(db).save_workflow("core-vote", {
        "name": "双核验 Agent 投票主干",
        "stage": "core",
        "enabled": True,
        "definition": {
            "nodes": [
                {"id": "A01", "type": "agent", "agent_id": "demand_agent", "depends_on": []},
                {"id": "TOOL", "type": "tool", "tool_id": "inventory_query", "arguments": {}, "depends_on": ["A01"]},
                {
                    "id": "LOOP", "type": "loop", "depends_on": ["TOOL"], "max_iterations": 3,
                    "until": {"field": "verification.verdict", "operator": "eq", "value": "pass"},
                    "body": {"nodes": [
                        {"id": "A02", "type": "agent", "agent_id": "matching_agent", "depends_on": []},
                        {"id": "VA", "type": "agent", "agent_id": "verifier_a", "depends_on": ["A02"]},
                        {"id": "VB", "type": "agent", "agent_id": "verifier_b", "depends_on": ["A02"]},
                        {"id": "VOTE", "type": "agent", "agent_id": "verification_vote", "depends_on": ["VA", "VB"]},
                        {"id": "REWORK", "type": "agent", "agent_id": "rework_policy", "depends_on": ["VOTE"], "when": {"field": "verification.verdict", "operator": "eq", "value": "rework"}},
                    ]},
                },
            ]
        },
    })
    run_id = "RUN-CORE-VOTE"
    db.create_run(run_id, scenario["id"], request)
    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))
    run = db.get_run(run_id)
    assert run["status"] == "awaiting_approval", run.get("result")
    assert run["result"]["core_workflow"]["id"] == "core-vote"
    assert len(run["result"]["core_workflow_runs"]) == 1
    assert run["result"]["core_workflow_runs"][0]["loop_mode"] is True
    assert set(run["result"]["core_workflow_runs"][0]["completed"]) == {"A01", "TOOL", "LOOP"}
    assert len(run["result"]["rounds"]) == 2
    assert run["result"]["rounds"][0]["verification"]["vote_summary"]["total"] == 2
    assert run["result"]["rounds"][0]["verification"]["verdict"] == "rework"
    assert run["result"]["final_verification"]["vote_summary"] == {"pass": 2, "total": 2, "rule": "majority"}
    assert run["result"]["final_verification"]["verdict"] == "pass"

def test_inventory_tool_result_changes_matching_decision(tmp_path: Path):
    db = Database(tmp_path / "inventory-tool-impact.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("heatwave-iii")
    materials = db.list_materials()
    water = next(item for item in materials if item["code"] == "MAT-WATER-001")
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": [],
        },
        "demand_items": [{"material_id": water["id"], "quantity": 1000, "priority": "P0", "deadline_hours": 8}],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    WorkflowRepository(db).save_workflow("tool-impact", {
        "name": "库存工具影响测试",
        "stage": "core",
        "enabled": True,
        "definition": {"nodes": [
            {"id": "A01", "type": "agent", "agent_id": "demand_agent", "depends_on": []},
            {"id": "TOOL", "type": "tool", "tool_id": "inventory_query", "arguments": {"material_id": 6}, "depends_on": ["A01"]},            {"id": "LOOP", "type": "loop", "depends_on": ["TOOL"], "max_iterations": 2,
             "until": {"field": "verification.verdict", "operator": "eq", "value": "pass"},
             "body": {"nodes": [
                 {"id": "A02", "type": "agent", "agent_id": "matching_agent", "depends_on": []},
                 {"id": "A03", "type": "agent", "agent_id": "verifier_agent", "depends_on": ["A02"]},
                 {"id": "REWORK", "type": "agent", "agent_id": "rework_policy", "depends_on": ["A03"],
                  "when": {"field": "verification.verdict", "operator": "eq", "value": "rework"}},
             ]},
            },
        ]},
    })
    run_id = "RUN-TOOL-IMPACT"
    db.create_run(run_id, scenario["id"], request)
    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))
    run = db.get_run(run_id)
    assert run["status"] == "needs_human"
    assert run["result"]["inventory_source"] == "inventory_query tool"
    assert run["result"]["execution_inventory_rows"] > 0
    assert run["result"]["final_verification"]["verdict"] == "rework"
    unmet_material_ids = {item["material_id"] for plan in run["result"]["final_plans"] for item in plan.get("unmet", [])}
    assert water["id"] in unmet_material_ids

def test_cross_run_memory_is_saved_without_unsafe_override(tmp_path: Path):
    db = Database(tmp_path / "cross-run-memory.db", database_url="")
    db.initialize()
    scenario = db.get_scenario("rainstorm-ii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": scenario["closed_routes"],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"],
                "quantity": item["quantity"],
                "priority": item["priority"],
                "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    for run_id in ("RUN-MEMORY-1", "RUN-MEMORY-2"):
        db.create_run(run_id, scenario["id"], request)
        asyncio.run(orchestrator_module.orchestrate(db, run_id, request))

    first = db.get_run("RUN-MEMORY-1")["result"]
    second = db.get_run("RUN-MEMORY-2")["result"]
    dispatch = first["orchestration"]["dispatch"]
    assert dispatch
    assert {item["stage"] for item in first["stage_metrics"]} >= set(orchestrator_module.STAGE_NAMES)
    assert all(float(item["duration_ms"]) >= 0 for item in first["stage_metrics"])
    assert all(item["allocation_mode"] == "capability-load-match" for item in dispatch)
    assert all(item["preferred_agent_id"] != "rag_retrieve" for item in dispatch)
    assert first["rework_directives"][0]["policy_selection"]["source"] == "deterministic-single-policy"
    assert second["rework_directives"][0]["policy_selection"]["source"] == "deterministic-single-policy"
    assert second["memory_context"]["matching_agent"]["successful_repair_policy"]["value"]["policy"] == "route_failover"
    assert second["rework_directives"][0]["experience_context"][0]["policy_id"] == "route_failover"
    repair_memories = [
        item for item in MemoryRepository(db).list_memories("matching_agent", limit=100)
        if item["memory_key"].startswith("repair_experience:")
    ]
    assert repair_memories
    assert repair_memories[0]["value"]["success_rate"] == 1.0
    memory_events = [event["type"] for event in db.events_after("RUN-MEMORY-2")]
    assert "memory.loaded" in memory_events
    assert "memory.saved" in memory_events

def test_builtin_dual_verifier_template_runs_without_manual_registration(tmp_path: Path):
    db = Database(tmp_path / "builtin-dual-template.db", database_url="")
    db.initialize()
    AgentRegistryService(db).sync_builtin_agents(AGENTS)
    scenario = db.get_scenario("rainstorm-ii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": scenario["closed_routes"],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"],
                "quantity": item["quantity"],
                "priority": item["priority"],
                "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    workflow = WorkflowRepository(db).instantiate_template(
        "TPL-DUAL-VERIFY-VOTE", {"id": "dual-template-runtime", "name": "双核验模板实例"}
    )
    assert workflow["id"] == "dual-template-runtime"
    run_id = "RUN-DUAL-TEMPLATE"
    db.create_run(run_id, scenario["id"], request)
    asyncio.run(orchestrator_module.orchestrate(db, run_id, request))
    run = db.get_run(run_id)
    assert run["status"] == "awaiting_approval", run.get("result")
    assert run["result"]["core_workflow"]["id"] == "dual-template-runtime"
    assert run["result"]["rounds"][0]["verification"]["vote_summary"]["total"] == 2
    assert run["result"]["final_verification"]["vote_summary"]["total"] == 2


def test_knowledge_tool_result_is_consumed_by_downstream_context(tmp_path: Path):
    db = Database(tmp_path / "knowledge-tool-consumption.db", database_url="")
    db.initialize()
    KnowledgeRepository(db).insert_document(
        "道路封闭处置规则", "应急规则", "test",
        [{"text": "暴雨导致道路封闭时，运输方案必须排除封闭路线并优先选择开放备用通道。", "section": "道路封闭", "char_start": 0, "char_end": 38}],
    )
    scenario = db.get_scenario("heatwave-iii")
    materials = db.list_materials()
    by_code = {item["code"]: item for item in materials}
    request = {
        "scenario_id": scenario["id"],
        "event": {
            "type": scenario["event_type"], "severity": scenario["severity"],
            "location": scenario["location"], "affected_population": scenario["affected_population"],
            "closed_route_ids": [],
        },
        "demand_items": [
            {
                "material_id": by_code[item["material_code"]]["id"], "quantity": item["quantity"],
                "priority": item["priority"], "deadline_hours": item["deadline_hours"],
            }
            for item in scenario["default_demand"]
        ],
        "weights": {"speed": 0.38, "cost": 0.27, "risk": 0.35},
    }
    WorkflowRepository(db).instantiate_template("TPL-EVIDENCE-DELIVERY", {"id": "knowledge-consumer", "name": "知识工具消费测试"})
    db.create_run("RUN-KNOWLEDGE-TOOL", scenario["id"], request)
    asyncio.run(orchestrator_module.orchestrate(db, "RUN-KNOWLEDGE-TOOL", request))
    run = db.get_run("RUN-KNOWLEDGE-TOOL")
    assert run["status"] == "awaiting_approval", run.get("result")
    assert run["result"]["execution_evidence"]
    consumed = [event for event in db.events_after("RUN-KNOWLEDGE-TOOL") if event["type"] == "tool.consumed"]
    assert any(event["payload"].get("tool_id") == "knowledge_search" for event in consumed)

def test_executor_priorities_use_effective_priority_values():
    schedule = {
        "dispatch": [
            {"agent_id": "matching_agent", "priority": 88, "effective_priority": 61, "load_penalty": 27},
            {"agent_id": "verifier_agent", "priority": 99, "effective_priority": 99, "load_penalty": 0},
        ]
    }
    priorities = orchestrator_module.build_executor_priorities(schedule)
    assert priorities == {"matching_agent": 61, "verifier_agent": 99}
    assert priorities["matching_agent"] < schedule["dispatch"][0]["priority"]

def test_audit_only_delivery_is_not_marked_applied_in_d6():
    traces = {
        "delivery_agent": {
            "mode": "agentarts",
            "parsed": {"summary": "stale summary"},
            "review_status": "audit-only",
            "discarded_fields": ["summary", "risk_alerts"],
        }
    }
    matrix = orchestrator_module.build_ai_decision_matrix(
        {"applied": False, "source": "deterministic-scorer"},
        traces,
        {"reports": []},
        [],
        {"enabled": True},
        {},
    )
    d6 = next(item for item in matrix if item["id"] == "D6")
    assert d6["applied"] is False
    assert d6["source"] == "agentarts-audit-only"
    assert d6["discarded_fields"] == ["summary", "risk_alerts"]


def test_failure_root_cause_mapping_is_single_source_of_truth():
    roots = orchestrator_module.classify_failure_root_causes([
        "STOCK-WH-A-MAT-1", "ROAD-R-1", "VEHICLE-WH-A", "COVERAGE-DST-1",
        "DATA-SCHEMA-MISMATCH", "LLM-PLANNER", "ENDPOINT-X", "TIMEOUT-A2A",
    ])
    assert roots == [
        "coverage_gap", "endpoint_failure", "fleet_insufficient", "inventory_shortage",
        "llm_failure", "road_closed", "rule_blocked", "timeout",
    ]
